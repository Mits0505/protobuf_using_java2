package example.practice;

import example.practice.complex.ComplexExample.ComplexMessage;
import example.practice.complex.ComplexExample.DummyMessage;

import java.io.IOException;
import java.util.Arrays;

public class ComplexMessageUsage {
    public static void main(String[] args) throws IOException {
        System.out.println("Complex Example");

        DummyMessage oneDummy = newDummyMessage(1, "one dummy message");

        ComplexMessage complexMessage= ComplexMessage.newBuilder()
                                                     .setOneDummy(oneDummy)
                                                     .addMultiDummy(newDummyMessage(2, "two dummy message"))
                                                     .addAllMultiDummy(Arrays.asList(newDummyMessage(3, "three dummy message")
                                                             ,newDummyMessage(4,"four dummy message")))
                                                     .build();
        System.out.println("Dummy message:");
        System.out.print(oneDummy);
        System.out.println("complex message:");
        System.out.print(complexMessage);
    }
    public static DummyMessage newDummyMessage(Integer id, String name){
      return DummyMessage.newBuilder()
              .setId(id)
              .setName(name).build();
    }
}
