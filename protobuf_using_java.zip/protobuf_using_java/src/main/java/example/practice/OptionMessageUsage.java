package example.practice;

import com.examples.options.OptionMessage2;
import java.io.IOException;

public class OptionMessageUsage {
    public static void main(String[] args) throws IOException {
       OptionMessage2.newBuilder().build();
    }
}
