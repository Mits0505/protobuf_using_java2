package example.practice;

public class SimpleMain {
    public static void main(String[] args){
        System.out.println("Hello World!");
    }
}
