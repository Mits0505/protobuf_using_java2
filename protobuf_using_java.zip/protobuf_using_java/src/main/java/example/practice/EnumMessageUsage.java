package example.practice;

import example.practice.enumerations.EnumExample.EnumMessage;
import java.io.IOException;

public class EnumMessageUsage {
    public static void main(String[] args) throws IOException {
        System.out.println("Example for Enums");
        //EnumMessage.Builder builder = EnumMessage.newBuilder();

        EnumMessage enumMessage=EnumMessage.newBuilder()
                   .setId(51)
                   .setDayOfWeek(EnumMessage.DayOfWeek.FRIDAY)
                   .build();

        System.out.print(enumMessage);
    }
}
