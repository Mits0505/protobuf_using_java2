package example.practice;

import com.google.protobuf.util.JsonFormat;
import example.practice.Simple.SimpleMessage;

import java.io.IOException;
import java.util.Arrays;

public class ProtoToJSONMain {
    public static void main(String[] args) throws IOException {

        SimpleMessage.Builder simpleMessageBuilder= SimpleMessage.newBuilder()
                .setId(51)  //set the id field.
                .setIsSimple(true) //set the is_simple field.
                .setName("Simple message for Mitali") //set the name field.
                .addSampleList(1)
                .addSampleList(2)
                .addSampleList(3)
                .addAllSampleList(Arrays.asList(4,5));

        // print this as a json.
        String jsonString=JsonFormat.printer()
               // .includingDefaultValueFields() --options.
                .print(simpleMessageBuilder);
        System.out.print(jsonString);

        // parse JSON into protobuf.
        SimpleMessage.Builder simpleMessageBuilder2 = SimpleMessage.newBuilder();
        JsonFormat.parser()
                .ignoringUnknownFields()
                .merge(jsonString, simpleMessageBuilder2);

        System.out.println("");
        System.out.println(simpleMessageBuilder2);
    }
}
