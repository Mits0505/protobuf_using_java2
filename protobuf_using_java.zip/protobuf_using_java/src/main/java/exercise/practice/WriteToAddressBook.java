package exercise.practice;

import com.exercise.practice.AddressBookProtoClass.Person;
import com.exercise.practice.AddressBookProtoClass.Person.PhoneNumber;
import com.exercise.practice.AddressBookProtoClass.Person.PhoneType;
import com.exercise.practice.AddressBookProtoClass.AddressBook;


import com.google.protobuf.Timestamp;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;

public class WriteToAddressBook {
    public static void main(String[] args) throws IOException {
        System.out.println("Address Book Usage..");
        Person p1 = Person.newBuilder()
                .setId(1)
                .setName("Mitali")
                .setEmail("mitali@gmail.com")
                .addAllPhones(Arrays.asList(newPhoneNumber("1234567890",PhoneType.HOME),
                        newPhoneNumber("0987654321",PhoneType.WORK)))
                .setLastUpdated(Timestamp.newBuilder().build())
                .build();

        Person p2 = Person.newBuilder()
                .setId(2)
                .setName("Lokesh")
                .setEmail("lokesh@gmail.com")
                .addAllPhones(Arrays.asList(newPhoneNumber("1134567890",PhoneType.HOME),
                        newPhoneNumber("0997654321",PhoneType.WORK)))
                .setLastUpdated(Timestamp.newBuilder().build())
                .build();

        AddressBook addressBook = AddressBook.newBuilder()
                .addAllPeople(Arrays.asList(p1,p2))
                .build();
        System.out.println("Content of address book..");
        System.out.println(addressBook);

        // Write AddressBook to a file.
        FileOutputStream fos=new FileOutputStream("addressbook.txt");
        addressBook.writeTo(fos);
        fos.close();
    }

    private static PhoneNumber newPhoneNumber(String phoneNumber, PhoneType phoneType) {
        return PhoneNumber.newBuilder()
                .setNumber(phoneNumber)
                .setType(phoneType)
                .build();
    }
}
