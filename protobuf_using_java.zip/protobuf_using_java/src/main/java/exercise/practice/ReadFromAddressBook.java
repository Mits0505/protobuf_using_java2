package exercise.practice;

import com.exercise.practice.AddressBookProtoClass.AddressBook;
import com.exercise.practice.AddressBookProtoClass.Person;
import com.exercise.practice.AddressBookProtoClass.Person.PhoneNumber;


import java.io.FileInputStream;
import java.io.IOException;

public class ReadFromAddressBook {
    public static void main(String[] args) throws IOException {
        System.out.println("Reading content from address book file..");

        FileInputStream fis = new FileInputStream("addressbook.txt");
        AddressBook addressBook = AddressBook.parseFrom(fis);
        fis.close();

        for(Person p : addressBook.getPeopleList())
        {
            System.out.println("Individual Person Details:");
            System.out.println("Id: "+p.getId());
            System.out.println("Name: "+p.getName());
            System.out.println("email: "+p.getEmail());
            for(PhoneNumber phoneNumber : p.getPhonesList()){
                switch(phoneNumber.getType()){
                    case MOBILE:
                        System.out.print("Mobile Number: ");
                        break;
                    case WORK:
                        System.out.print("Work Phone Number: ");
                        break;
                    case HOME:
                        System.out.print("Home Phone Number: ");
                        break;
                }
                System.out.println(phoneNumber.getNumber());
            }
        }
    }
}
